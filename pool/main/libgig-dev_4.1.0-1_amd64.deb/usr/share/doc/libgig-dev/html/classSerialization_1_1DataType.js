var classSerialization_1_1DataType =
[
    [ "DataType", "classSerialization_1_1DataType.html#a7f76841697908ec5651c6e3e7b8030bc", null ],
    [ "DataType", "classSerialization_1_1DataType.html#a90a2512a45b559eeb8f21c89fbe3d29b", null ],
    [ "asLongDescr", "classSerialization_1_1DataType.html#a81be2fdba6393badc0acbabf0490c2a0", null ],
    [ "baseTypeName", "classSerialization_1_1DataType.html#a5aefb02c785630a45c1678eed61768ca", null ],
    [ "customTypeName", "classSerialization_1_1DataType.html#aeac54ea77f26f2dcb51b2aa81a9b90bb", null ],
    [ "isBool", "classSerialization_1_1DataType.html#a87a7210352b007b17c463af01f13091f", null ],
    [ "isClass", "classSerialization_1_1DataType.html#ab438fe4986fe64aa1a030db5a709a7ab", null ],
    [ "isEnum", "classSerialization_1_1DataType.html#aa4573dc9ad4c7cf8bedc0ae08fa9b493", null ],
    [ "isInteger", "classSerialization_1_1DataType.html#ac16e80cf80ea5d0ac1461b9df64fc3e5", null ],
    [ "isPointer", "classSerialization_1_1DataType.html#a41353c32580ca573ce98e4747980d84d", null ],
    [ "isPrimitive", "classSerialization_1_1DataType.html#a040fdc053173fbdc19b301c5399b0e6a", null ],
    [ "isReal", "classSerialization_1_1DataType.html#a76d18b1d568b0e0f55dc886590897749", null ],
    [ "isSigned", "classSerialization_1_1DataType.html#a4b50a07eb510911b4503f886998f6257", null ],
    [ "isValid", "classSerialization_1_1DataType.html#a9a30b9afd28183cf3ae298d22701627f", null ],
    [ "operator bool", "classSerialization_1_1DataType.html#a63ffb637e1ced72f37bee71ce0a40688", null ],
    [ "operator!=", "classSerialization_1_1DataType.html#a763335c8290f34c6a9ea8d38c93c95d6", null ],
    [ "operator<", "classSerialization_1_1DataType.html#aac09b3c493116227d32631ef036872ab", null ],
    [ "operator==", "classSerialization_1_1DataType.html#ac57550c8d90148c7fa27491d934c814b", null ],
    [ "operator>", "classSerialization_1_1DataType.html#aa36b3880e79f94837e25054c6bb02a6c", null ],
    [ "size", "classSerialization_1_1DataType.html#afc871b28e0d4a6bfa8d9355de3aa244d", null ],
    [ "Archive", "classSerialization_1_1DataType.html#a4f1345bc28f2fd55b5ef2717d251ceea", null ]
];