var classKorg_1_1KMPInstrument =
[
    [ "KMPInstrument", "classKorg_1_1KMPInstrument.html#a136ba00c942587af19c6bd7b9bb000a5", null ],
    [ "~KMPInstrument", "classKorg_1_1KMPInstrument.html#a5ec48eb3cd73c7eae80eeebeb4d13131", null ],
    [ "FileName", "classKorg_1_1KMPInstrument.html#acbcd028a130ed9f8a5029e7ec6379a9c", null ],
    [ "GetRegion", "classKorg_1_1KMPInstrument.html#aba11d14f1340568be1a52361e1ac8927", null ],
    [ "GetRegionCount", "classKorg_1_1KMPInstrument.html#aa66cf1db6775e1d02e97243abb813c4c", null ],
    [ "Name", "classKorg_1_1KMPInstrument.html#a4bd211e192f344a9a030fd1024ba4b1a", null ],
    [ "Use2ndStart", "classKorg_1_1KMPInstrument.html#af22a5f23deb7d2c2fc4f15aef00fe21a", null ],
    [ "Attributes", "classKorg_1_1KMPInstrument.html#a2ca28700a4ee0b8b1a3c36477d47f624", null ],
    [ "Name16", "classKorg_1_1KMPInstrument.html#a0fbaae8244bedaa8c11f5be517460fc7", null ],
    [ "Name24", "classKorg_1_1KMPInstrument.html#a484c2102d6fd0385c9f1c1cfdb796f47", null ]
];