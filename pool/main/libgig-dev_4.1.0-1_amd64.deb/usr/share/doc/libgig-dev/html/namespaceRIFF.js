var namespaceRIFF =
[
    [ "Chunk", "classRIFF_1_1Chunk.html", "classRIFF_1_1Chunk" ],
    [ "Exception", "classRIFF_1_1Exception.html", "classRIFF_1_1Exception" ],
    [ "File", "classRIFF_1_1File.html", "classRIFF_1_1File" ],
    [ "List", "classRIFF_1_1List.html", "classRIFF_1_1List" ],
    [ "progress_t", "structRIFF_1_1progress__t.html", "structRIFF_1_1progress__t" ]
];