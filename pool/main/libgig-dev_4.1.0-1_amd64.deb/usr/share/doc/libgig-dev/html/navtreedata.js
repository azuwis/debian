var NAVTREE =
[
  [ "libgig", "index.html", [
    [ "Intro", "index.html#Intro", null ],
    [ "License", "index.html#License", null ],
    [ "Examples", "index.html#Examples", null ],
    [ "Portability", "index.html#Portability", null ],
    [ "Bugs", "index.html#Bugs", null ],
    [ "Outro", "index.html#Outro", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Akai_8cpp_source.html",
"classDLS_1_1Instrument.html#a50baa981bf45bcc2b2ffebe1d1b554a0",
"classRIFF_1_1Chunk.html#a131b150e1a7e839eb8276df03004bed9",
"classSerialization_1_1Archive.html#a1cf38cb2c39379b8975d0f0ca1977364",
"classgig_1_1DimensionRegion.html#af8453e47889c8cc1fbbfca7ebed24e95",
"classgig_1_1Region.html#a4d6c2074e15a3b1936c0ec3da1b5fd65",
"functions_func_a.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';