var structgig_1_1crossfade__t =
[
    [ "serialize", "structgig_1_1crossfade__t.html#afa059c364fa065e5a011b851a4657339", null ],
    [ "in_end", "structgig_1_1crossfade__t.html#a03ded166801679ea2f3c36cd300baeb2", null ],
    [ "in_start", "structgig_1_1crossfade__t.html#a0f70de3e5653f95e8a30cdf1afeeb6ab", null ],
    [ "out_end", "structgig_1_1crossfade__t.html#a3f0f482a9ef1ebb4b48877da8080ee93", null ],
    [ "out_start", "structgig_1_1crossfade__t.html#ade1ea53bdd5b3665e4d4dd6b5b0b0b8a", null ]
];