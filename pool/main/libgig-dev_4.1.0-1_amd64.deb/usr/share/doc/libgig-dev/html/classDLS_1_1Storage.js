var classDLS_1_1Storage =
[
    [ "DeleteChunks", "classDLS_1_1Storage.html#ae58532f867ab39759adffcbe1e978e50", null ],
    [ "UpdateChunks", "classDLS_1_1Storage.html#af8c9b6395681770afed0f9f9c9483afa", null ]
];