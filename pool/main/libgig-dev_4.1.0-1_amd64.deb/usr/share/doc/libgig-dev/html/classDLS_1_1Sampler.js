var classDLS_1_1Sampler =
[
    [ "Sampler", "classDLS_1_1Sampler.html#ab0abd925b938e662cad8c64e4e2241ae", null ],
    [ "~Sampler", "classDLS_1_1Sampler.html#a1fcf4015432abcd6803417a44f032f44", null ],
    [ "AddSampleLoop", "classDLS_1_1Sampler.html#a717d9354651251aa9abec36801f09630", null ],
    [ "CopyAssign", "classDLS_1_1Sampler.html#a22fd47782d302ca179c20d0de5545ab3", null ],
    [ "DeleteChunks", "classDLS_1_1Sampler.html#a037423fcb44d300db7f1f3babb7e5446", null ],
    [ "DeleteSampleLoop", "classDLS_1_1Sampler.html#ad6cd0f66b87d6fe61b8dc8e8392a890b", null ],
    [ "SetGain", "classDLS_1_1Sampler.html#ad17d4c5815792cf37ea8c5fdbcb9b38e", null ],
    [ "UpdateChunks", "classDLS_1_1Sampler.html#a19cdf2b61f2337735bd73299f9486f02", null ],
    [ "FineTune", "classDLS_1_1Sampler.html#a530a5c330b471c5b4002541e456f19f0", null ],
    [ "Gain", "classDLS_1_1Sampler.html#aded64bedf4afdf6773e4ba872157c344", null ],
    [ "NoSampleCompression", "classDLS_1_1Sampler.html#aabea19a625908c7a0d45f70bc537cab4", null ],
    [ "NoSampleDepthTruncation", "classDLS_1_1Sampler.html#a7ce9651c36305d5054ca7aff6a132e77", null ],
    [ "pParentList", "classDLS_1_1Sampler.html#a1a8a65b6c187ee217529d0531ef4173d", null ],
    [ "pSampleLoops", "classDLS_1_1Sampler.html#acb1d8ac5aed3310787e0a960cd82ef04", null ],
    [ "SampleLoops", "classDLS_1_1Sampler.html#a7be8a9078496d44946af3230c2ccc80c", null ],
    [ "SamplerOptions", "classDLS_1_1Sampler.html#adf8b1dc9009b3be0ee4251dfa1d53dee", null ],
    [ "uiHeaderSize", "classDLS_1_1Sampler.html#a49f23f4abf06587852ac0e130ffbdf60", null ],
    [ "UnityNote", "classDLS_1_1Sampler.html#a82d42a7c4f1df945c8b69ec10b3dfce5", null ]
];