var namespaceSerialization =
[
    [ "Archive", "classSerialization_1_1Archive.html", "classSerialization_1_1Archive" ],
    [ "DataType", "classSerialization_1_1DataType.html", "classSerialization_1_1DataType" ],
    [ "Exception", "classSerialization_1_1Exception.html", "classSerialization_1_1Exception" ],
    [ "Member", "classSerialization_1_1Member.html", "classSerialization_1_1Member" ],
    [ "Object", "classSerialization_1_1Object.html", "classSerialization_1_1Object" ],
    [ "UID", "classSerialization_1_1UID.html", "classSerialization_1_1UID" ]
];