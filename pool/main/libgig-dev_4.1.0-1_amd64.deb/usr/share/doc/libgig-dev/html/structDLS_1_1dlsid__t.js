var structDLS_1_1dlsid__t =
[
    [ "abData", "structDLS_1_1dlsid__t.html#a8e2b48b155f2d6bca59ed6247dca43ef", null ],
    [ "ulData1", "structDLS_1_1dlsid__t.html#a1b88582d787f6600485f7be764772d13", null ],
    [ "usData2", "structDLS_1_1dlsid__t.html#ab81d4ebe05bb96132b78925b1c0e7c35", null ],
    [ "usData3", "structDLS_1_1dlsid__t.html#a6b20e99b5afed139ea14bad1089afc42", null ]
];