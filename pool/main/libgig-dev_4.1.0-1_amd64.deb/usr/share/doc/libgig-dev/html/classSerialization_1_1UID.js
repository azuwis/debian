var classSerialization_1_1UID =
[
    [ "isValid", "classSerialization_1_1UID.html#a2e5257c004a17e84c0b230af83671561", null ],
    [ "operator bool", "classSerialization_1_1UID.html#a2a8e9e104e2945f4e8ba15a2389932f7", null ],
    [ "operator!=", "classSerialization_1_1UID.html#a78c6ad16d9d27ec17a0b2475bc3be574", null ],
    [ "operator<", "classSerialization_1_1UID.html#a06b7e1ab94a4a13fe9f935c5db5fa5be", null ],
    [ "operator==", "classSerialization_1_1UID.html#a672be4d99a4b871ec682baf863b055fd", null ],
    [ "operator>", "classSerialization_1_1UID.html#ab5e0f7a09e3a81cd2b9bb7980a080c1a", null ],
    [ "id", "classSerialization_1_1UID.html#ac16f71fb0f048da24c33191476bccf6b", null ],
    [ "size", "classSerialization_1_1UID.html#a61387dbb832688fe9dd697ab292d2657", null ]
];