var namespacegig =
[
    [ "buffer_t", "structgig_1_1buffer__t.html", "structgig_1_1buffer__t" ],
    [ "crossfade_t", "structgig_1_1crossfade__t.html", "structgig_1_1crossfade__t" ],
    [ "dimension_def_t", "structgig_1_1dimension__def__t.html", "structgig_1_1dimension__def__t" ],
    [ "DimensionRegion", "classgig_1_1DimensionRegion.html", "classgig_1_1DimensionRegion" ],
    [ "eg_opt_t", "structgig_1_1eg__opt__t.html", "structgig_1_1eg__opt__t" ],
    [ "Exception", "classgig_1_1Exception.html", "classgig_1_1Exception" ],
    [ "File", "classgig_1_1File.html", "classgig_1_1File" ],
    [ "Group", "classgig_1_1Group.html", "classgig_1_1Group" ],
    [ "Instrument", "classgig_1_1Instrument.html", "classgig_1_1Instrument" ],
    [ "leverage_ctrl_t", "structgig_1_1leverage__ctrl__t.html", "structgig_1_1leverage__ctrl__t" ],
    [ "MidiRule", "classgig_1_1MidiRule.html", "classgig_1_1MidiRule" ],
    [ "MidiRuleAlternator", "classgig_1_1MidiRuleAlternator.html", "classgig_1_1MidiRuleAlternator" ],
    [ "MidiRuleCtrlTrigger", "classgig_1_1MidiRuleCtrlTrigger.html", "classgig_1_1MidiRuleCtrlTrigger" ],
    [ "MidiRuleLegato", "classgig_1_1MidiRuleLegato.html", "classgig_1_1MidiRuleLegato" ],
    [ "MidiRuleUnknown", "classgig_1_1MidiRuleUnknown.html", "classgig_1_1MidiRuleUnknown" ],
    [ "playback_state_t", "structgig_1_1playback__state__t.html", "structgig_1_1playback__state__t" ],
    [ "range_t", "structgig_1_1range__t.html", "structgig_1_1range__t" ],
    [ "Region", "classgig_1_1Region.html", "classgig_1_1Region" ],
    [ "Sample", "classgig_1_1Sample.html", "classgig_1_1Sample" ],
    [ "Script", "classgig_1_1Script.html", "classgig_1_1Script" ],
    [ "ScriptGroup", "classgig_1_1ScriptGroup.html", "classgig_1_1ScriptGroup" ]
];