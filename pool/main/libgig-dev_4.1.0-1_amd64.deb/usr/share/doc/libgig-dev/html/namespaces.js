var namespaces =
[
    [ "DLS", "namespaceDLS.html", null ],
    [ "gig", "namespacegig.html", null ],
    [ "Korg", "namespaceKorg.html", null ],
    [ "RIFF", "namespaceRIFF.html", null ],
    [ "Serialization", "namespaceSerialization.html", null ],
    [ "sf2", "namespacesf2.html", null ]
];