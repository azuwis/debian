var classgig_1_1Group =
[
    [ "Group", "classgig_1_1Group.html#a0b2b6041c0b01b20bf2aa0f1a86982ba", null ],
    [ "~Group", "classgig_1_1Group.html#ac5f2cce567d51497692b6cf20b5221e2", null ],
    [ "AddSample", "classgig_1_1Group.html#aed360049832e5e7b589dc22155b50e77", null ],
    [ "DeleteChunks", "classgig_1_1Group.html#aad405a844ffce4a8a1ca9c5822f49612", null ],
    [ "GetFirstSample", "classgig_1_1Group.html#a2fdf8495937953569eacf78ee0ce21a5", null ],
    [ "GetNextSample", "classgig_1_1Group.html#a725a9ba5fa03d80b1ad08de28b099158", null ],
    [ "MoveAll", "classgig_1_1Group.html#a7e22bbe52a38efc76ad52aa9bdc02882", null ],
    [ "UpdateChunks", "classgig_1_1Group.html#a9719db848b059e1ad5e17d469c82b842", null ],
    [ "File", "classgig_1_1Group.html#a68d15876ad188b7628261b12d0eac8aa", null ],
    [ "Name", "classgig_1_1Group.html#afaaaa945fab9fb997ab3b49518a69ba9", null ]
];