var structgig_1_1dimension__def__t =
[
    [ "bits", "structgig_1_1dimension__def__t.html#a6e587de2373ef83a5b70dbe210b56ee5", null ],
    [ "dimension", "structgig_1_1dimension__def__t.html#a54aabea99b1a45946fc9979e84320cfe", null ],
    [ "split_type", "structgig_1_1dimension__def__t.html#ad0a78a0a22f9dbf2f72dbd934bff3fe2", null ],
    [ "zone_size", "structgig_1_1dimension__def__t.html#a78559d748ffe4be150e014672aeef435", null ],
    [ "zones", "structgig_1_1dimension__def__t.html#a5df483f2b2c16c0a3479d611fd6dc1fe", null ]
];