
#ifndef LIBIMEPINYIN_EXPORT_H
#define LIBIMEPINYIN_EXPORT_H

#ifdef LIBIMEPINYIN_STATIC_DEFINE
#  define LIBIMEPINYIN_EXPORT
#  define LIBIMEPINYIN_NO_EXPORT
#else
#  ifndef LIBIMEPINYIN_EXPORT
#    ifdef IMEPinyin_EXPORTS
        /* We are building this library */
#      define LIBIMEPINYIN_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBIMEPINYIN_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBIMEPINYIN_NO_EXPORT
#    define LIBIMEPINYIN_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBIMEPINYIN_DEPRECATED
#  define LIBIMEPINYIN_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBIMEPINYIN_DEPRECATED_EXPORT
#  define LIBIMEPINYIN_DEPRECATED_EXPORT LIBIMEPINYIN_EXPORT LIBIMEPINYIN_DEPRECATED
#endif

#ifndef LIBIMEPINYIN_DEPRECATED_NO_EXPORT
#  define LIBIMEPINYIN_DEPRECATED_NO_EXPORT LIBIMEPINYIN_NO_EXPORT LIBIMEPINYIN_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBIMEPINYIN_NO_DEPRECATED
#    define LIBIMEPINYIN_NO_DEPRECATED
#  endif
#endif

#endif /* LIBIMEPINYIN_EXPORT_H */
